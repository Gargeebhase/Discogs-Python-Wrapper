import os
import requests

session = requests.Session()
session.params = {}


from .dv import DV